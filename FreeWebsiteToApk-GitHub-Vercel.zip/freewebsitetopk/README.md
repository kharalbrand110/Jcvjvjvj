# FreeWebsiteToApk — GitHub + Vercel deployment

## What is included
- Responsive white-theme frontend in `public/`
- Vercel serverless API routes in `api/`
- `/api/health` reports whether an external APK builder is connected
- `/api/build` securely proxies build requests to your separate APK build server
- `server.js` for local development

## Deploy the website through GitHub and Vercel

1. Create a new GitHub repository, for example `free-website-to-apk`.
2. Upload all files and folders from this project to the repository root. Do not upload only `index.html`.
3. Sign in to Vercel and choose **Add New → Project**.
4. Import the GitHub repository and authorize Vercel if requested.
5. Keep the project root as `./`. No build command is required for the static frontend; Vercel detects the `api/` serverless functions.
6. Click **Deploy**. Your website will receive a Vercel URL.

## Connect the real APK build server

Vercel does not provide a full Android SDK/Gradle build machine for this workflow. Run the included Node.js builder (`server.js`) on a separate Linux VPS/container with:
- Node.js 20+
- Java JDK
- Android SDK command-line tools, platform and build-tools
- Android SDK environment variables (`ANDROID_HOME` or `ANDROID_SDK_ROOT`)
- Enough CPU, RAM and disk for Gradle builds

After deploying the builder, open **Vercel → Project → Settings → Environment Variables** and add:

- Name: `APK_BUILDER_URL`
- Value: the public HTTPS base URL of your builder server, with no trailing slash (example format: `https://builder.example.com`)

Redeploy the Vercel project after adding or changing the variable. The Vercel `/api/build` route forwards the HTML/app metadata to `https://your-builder-host/api/build`.

On the builder server, set `ANDROID_BUILDER_READY=true` only after Java, Android SDK and Gradle are installed and tested.

## Important production safeguards
- Protect the builder API with authentication before public launch.
- Add per-user quotas, request throttling, job queueing and build timeouts.
- Run each build in an isolated container with CPU, memory and disk limits.
- Restrict outbound network access and validate all submitted content.
- Never accept arbitrary shell commands or expose signing keys in browser code.
- Configure a secure release-signing process separately. The current build target is a debug APK, not a Play Store-ready signed release.
- Add cleanup for abandoned build directories and logs.

## Current feature scope
Included: paste HTML, app name, package name, version, responsive UI, Vercel frontend hosting, health endpoint, build proxy.

Not yet included: ZIP upload, URL import, custom app icon/splash, About/Privacy editor, user accounts, signed release APKs, build queue/status UI. These should be added before marketing it as a complete public converter.
